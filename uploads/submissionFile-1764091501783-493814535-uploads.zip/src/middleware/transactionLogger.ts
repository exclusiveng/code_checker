import { AppDataSource } from "../config/data-source";
import { Wallet } from "../entities/Wallet";
import { WalletTransaction, TransactionType } from "../entities/WalletTransaction"; // Assuming TransactionType is exported from here

/**
 * Logs a wallet transaction event automatically.
 * Can be used anywhere to create a clean transaction record.
 */
export const logWalletTransaction = async (options: {
  wallet: Wallet;
  type: TransactionType;
  points: number;
  nairaValue?: number;
  description?: string;
}) => {
  const { wallet, type, points, nairaValue = points, description } = options;

  try {
    const txRepo = AppDataSource.getRepository(WalletTransaction);

    const tx = txRepo.create({
      wallet,
      type,
      points,
      nairaValue,
      description,
    });

    await txRepo.save(tx);

    // Optional: return log entry for chaining or debugging
    return tx;
  } catch (error) {
    console.error("Transaction log error:", error);
  }
};
