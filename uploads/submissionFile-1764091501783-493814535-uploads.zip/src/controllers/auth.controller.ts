import { Request, Response } from "express";
import { AppDataSource } from "../config/data-source";
import { User, UserRole } from "../entities/User";
import { Referral } from "../entities/Referral";
import { generateToken } from "../utils/jwt";
import { mailTransporter } from "../config/mail";
import { generateOTP, generateExpiry } from "../utils/otp";


export const register = async (req: Request, res: Response) => {
  try {
    const {
      email,
      password,
      name,
      phoneNumber,
      nin,
      role,
      state,
      city,
      area,
      street,
      houseNumber,
      nearestBusStop,
      referralCode,
    } = req.body;

    // Validate required fields
    if (!email || !password || !name || !phoneNumber || !nin) {
      return res.status(400).json({ message: "All required fields must be filled" });
    }

    const userRepo = AppDataSource.getRepository(User);
    const referralRepo = AppDataSource.getRepository(Referral);

    // Normalize email
    const normalizedEmail = email.toLowerCase();

    // Check for existing user
    const existingUser = await userRepo.findOne({ where: { email: normalizedEmail } });
    if (existingUser) {
      return res.status(400).json({ message: "User already exists" });
    }

    // Validate role
    const assignedRole: UserRole = Object.values(UserRole).includes(role)
      ? role
      : UserRole.HOUSEHOLD;

    // Create new user
    const newUser = userRepo.create({
      email: normalizedEmail,
      password,
      name,
      phoneNumber,
      nin,
      role: assignedRole,
      state,
      city,
      area,
      street,
      houseNumber,
      nearestBusStop,
    });

    await userRepo.save(newUser);

    // Handle referral logic
    if (referralCode) {
      const referrer = await userRepo.findOne({ where: { referralCode } });
      if (referrer) {
        const referral = referralRepo.create({
          referrer,
          referredUser: newUser,
        });
        await referralRepo.save(referral);
      }
    }

    // Generate token
    const token = generateToken(newUser.id);

    return res.status(201).json({
      message: "User created successfully",
      token,
      user: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        phoneNumber: newUser.phoneNumber,
        role: newUser.role,
        referralCode: newUser.referralCode,
        address: {
          state: newUser.state,
          city: newUser.city,
          area: newUser.area,
          street: newUser.street,
          houseNumber: newUser.houseNumber,
          nearestBusStop: newUser.nearestBusStop,
        },
      },
    });
  } catch (error) {
    console.error("Register error:", error);
    return res.status(500).json({ message: "Server error during registration" });
  }
};

export const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const userRepo = AppDataSource.getRepository(User);

    const user = await userRepo.findOne({ where: { email: email.toLowerCase() } });
    if (!user) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    const isValidPassword = await user.validatePassword(password);
    if (!isValidPassword) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    // Generate and save OTP
    const otp = generateOTP();
    user.otpCode = otp;
    user.otpExpiresAt = generateExpiry(5); // expires in 5 minutes
    await userRepo.save(user);

    // Send OTP via email
    await mailTransporter.sendMail({
      from: `"Waste2Cash" <${process.env.SMTP_USER}>`,
      to: user.email,
      subject: "Your Waste2Cash Login OTP",
      html: `
        <p>Hello ${user.name},</p>
        <p>Your OTP for logging into Waste2Cash is <b>${otp}</b>.</p>
        <p>This code will expire in <b>5 minutes</b>.</p>
      `,
    });

    return res.status(200).json({
      message: "OTP sent to your registered email",
      email: user.email,
    });
  } catch (error) {
    console.error("Login error:", error);
    return res.status(500).json({ message: "Server error during login" });
  }
};

export const verifyOTP = async (req: Request, res: Response) => {
  try {
    const { email, otp } = req.body;
    const userRepo = AppDataSource.getRepository(User);

    const user = await userRepo.findOne({ where: { email: email.toLowerCase() } });
    if (!user || !user.otpCode || !user.otpExpiresAt) {
      return res.status(400).json({ message: "OTP not found or expired" });
    }

    const now = new Date();
    if (user.otpCode !== otp) {
      return res.status(400).json({ message: "Invalid OTP" });
    }

    if (now > user.otpExpiresAt) {
      user.otpCode = null;
      user.otpExpiresAt = null;
      await userRepo.save(user);
      return res.status(400).json({ message: "OTP expired" });
    }

    // Clear OTP data after verification
    user.otpCode = null;
    user.otpExpiresAt = null;
    await userRepo.save(user);

    const token = generateToken(user.id);

    return res.status(200).json({
      message: "Login successful",
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        phoneNumber: user.phoneNumber,
        role: user.role,
        address: user.fullAddress,
      },
    });
  } catch (error) {
    console.error("OTP verification error:", error);
    return res.status(500).json({ message: "Server error during OTP verification" });
  }
};
