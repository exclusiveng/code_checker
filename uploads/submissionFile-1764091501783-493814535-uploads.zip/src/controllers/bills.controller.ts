import { Response } from "express";
import { AppDataSource } from "../config/data-source";
import { User } from "../entities/User";
import { Wallet } from "../entities/Wallet";
import { initiateBillPayment } from "../services/flutterwave.service";
import { logWalletTransaction } from "../middleware/transactionLogger";
import { TransactionType } from "../entities/WalletTransaction";

export const payBill = async (req: any, res: Response) => {
  const userId = req.user.id;
  const { type, amount, customer, biller_code, biller_name } = req.body;

  // Basic validation
  if (!type || !amount || !customer || !biller_code || !biller_name) {
    return res.status(400).json({ message: "Missing required fields for bill payment." });
  }

  const validTypes = ["AIRTIME", "DATA", "POWER"];
  if (!validTypes.includes(type.toUpperCase())) {
    return res.status(400).json({ message: "Invalid bill type. Must be one of: AIRTIME, DATA, POWER." });
  }

  const numericAmount = Number(amount);
  if (isNaN(numericAmount) || numericAmount <= 0) {
    return res.status(400).json({ message: "Invalid amount." });
  }

  const queryRunner = AppDataSource.createQueryRunner();
  await queryRunner.connect();
  await queryRunner.startTransaction();

  try {
    const userRepo = queryRunner.manager.getRepository(User);
    const walletRepo = queryRunner.manager.getRepository(Wallet);

    const user = await userRepo.findOne({ where: { id: userId } });
    if (!user) {
      await queryRunner.rollbackTransaction();
      return res.status(404).json({ message: "User not found." });
    }

    const wallet = await walletRepo.findOne({ where: { user: { id: userId } } });
    if (!wallet) {
      await queryRunner.rollbackTransaction();
      return res.status(404).json({ message: "Wallet not found." });
    }

    if (wallet.availableBalanceNaira < numericAmount) {
      await queryRunner.rollbackTransaction();
      return res.status(400).json({ message: "Insufficient balance." });
    }

    // 1. Debit user's wallet
    wallet.availableBalanceNaira -= numericAmount;
    await walletRepo.save(wallet);

    // 2. Initiate payment with Flutterwave
    const reference = `W2C-BILL-${userId}-${Date.now()}`;
    const paymentResult = await initiateBillPayment(
      type.toUpperCase(),
      customer,
      numericAmount,
      reference,
      biller_code,
      biller_name
    );

    if (paymentResult.status !== "success") {
      // If Flutterwave payment fails, roll back the wallet debit
      await queryRunner.rollbackTransaction();
      return res.status(400).json({
        message: "Bill payment failed.",
        details: paymentResult.message,
      });
    }

    // 3. Log the transaction
    await logWalletTransaction({
      wallet,
      type: TransactionType.BILLS,
      points: numericAmount,
      description: `Bill payment: ${type} to ${customer}`,
    });

    // 4. Commit transaction
    await queryRunner.commitTransaction();

    return res.status(200).json({
      message: "Bill payment successful.",
      data: paymentResult.data,
    });
  } catch (error: any) {
    await queryRunner.rollbackTransaction();
    console.error("Bill payment error:", error);
    return res.status(500).json({
      message: "An error occurred during bill payment.",
      error: error.message,
    });
  } finally {
    await queryRunner.release();
  }
};