import { Request, Response } from "express";
import { AppDataSource } from "../config/data-source";
import { User } from "../entities/User";
import { Wallet } from "../entities/Wallet";
import { Transaction, TransactionType } from "../entities/Transaction";
import { TransactionType as WalletTransactionType, WalletTransaction } from "../entities/WalletTransaction";
import { logWalletTransaction } from "../middleware/transactionLogger";

export const transferToFriend = async (req: any, res: Response) => {
  try {
    const senderId: string = req.user.id;
    const { recipientEmail, amount } = req.body;

    if (!recipientEmail || !amount) {
      return res.status(400).json({ message: "Recipient email and amount are required" });
    }

    const userRepo = AppDataSource.getRepository(User);
    const walletRepo = AppDataSource.getRepository(Wallet);
    const transactionRepo = AppDataSource.getRepository(Transaction);

    const sender = await userRepo.findOne({ where: { id: senderId } });
    if (!sender) return res.status(404).json({ message: "Sender not found" });

    const recipient = await userRepo.findOne({
      where: { email: recipientEmail.toLowerCase() },
    });
    if (!recipient) return res.status(404).json({ message: "Recipient not found" });
    if (recipient.id === sender.id)
      return res.status(400).json({ message: "Cannot transfer to yourself" });

    const senderWallet = await walletRepo.findOne({
      where: { user: { id: sender.id } },
    });
    const recipientWallet = await walletRepo.findOne({
      where: { user: { id: recipient.id } },
    });

    if (!senderWallet) return res.status(400).json({ message: "Sender wallet not found" });
    if (!recipientWallet) return res.status(400).json({ message: "Recipient wallet not found" });

    const numericAmount = Number(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return res.status(400).json({ message: "Invalid transfer amount" });
    }

    if (senderWallet.availableBalanceNaira < numericAmount) {
      return res.status(400).json({ message: "Insufficient balance" });
    }

    // Use QueryRunner for atomic transaction
    const queryRunner = AppDataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      senderWallet.availableBalanceNaira -= numericAmount;
      recipientWallet.availableBalanceNaira += numericAmount;

      await queryRunner.manager.save(senderWallet);
      await queryRunner.manager.save(recipientWallet);

      const newTransaction = transactionRepo.create({
        sender,
        recipient,
        amount: numericAmount,
        type: TransactionType.TRANSFER,
      });

      await queryRunner.manager.save(newTransaction);

      // Log wallet transactions for sender and recipient
      await logWalletTransaction({
        wallet: senderWallet,
        type: WalletTransactionType.TRANSFER_OUT,
        points: numericAmount,
        description: `Sent to ${recipient.email}`,
      });
      await logWalletTransaction({
        wallet: recipientWallet,
        type: WalletTransactionType.TRANSFER_IN,
        points: numericAmount,
        description: `Received from ${sender.email}`,
      });

      await queryRunner.commitTransaction();
      return res.status(200).json({
        message: "Transfer successful",
        transaction: {
          id: newTransaction.id,
          amount: newTransaction.amount,
          type: newTransaction.type,
          createdAt: newTransaction.createdAt,
          sender: {
            id: sender.id,
            name: sender.name,
            email: sender.email,
          },
          recipient: {
            id: recipient.id,
            name: recipient.name,
            email: recipient.email,
          },
        },
      });
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  } catch (error) {
    console.error("Transfer error:", error);
    return res.status(500).json({ message: "Server error during transfer" });
  }
};


export const getWalletBalance = async (req: any, res: Response) => {
  try {
    const userId: string = req.user.id;
    const walletRepo = AppDataSource.getRepository(Wallet);
    const userRepo = AppDataSource.getRepository(User);

    const user = await userRepo.findOne({ where: { id: userId } });
    if (!user) return res.status(404).json({ message: "User not found" });

    let wallet = await walletRepo.findOne({ where: { user: { id: user.id } } });

    // Create wallet if missing (first-time user)
    if (!wallet) {
      wallet = walletRepo.create({
        user,
        totalPoints: 0,
        totalEarningsNaira: 0,
        availableBalanceNaira: 0,
      });
      await walletRepo.save(wallet);
    }

    return res.status(200).json({
      message: "Wallet balance fetched successfully",
      wallet: {
        totalPoints: wallet.totalPoints,
        totalEarningsNaira: wallet.totalEarningsNaira,
        availableBalance: wallet.availableBalanceNaira,
      },
    });
  } catch (error) {
    console.error("Wallet fetch error:", error);
    return res.status(500).json({ message: "Server error while fetching wallet balance" });
  }
};

export const getWalletActivity = async (req: any, res: Response) => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;

    const walletRepo = AppDataSource.getRepository(Wallet);
    const txRepo = AppDataSource.getRepository(WalletTransaction);

    const wallet = await walletRepo.findOne({
      where: { user: { id: userId } },
    });

    if (!wallet) return res.status(404).json({ message: "Wallet not found" });

    const [transactions, total] = await txRepo.findAndCount({
      where: { wallet: { id: wallet.id } },
      order: { createdAt: "DESC" },
      skip: (page - 1) * limit,
      take: limit,
    });

    res.status(200).json({
      message: "Wallet activity fetched successfully",
      page,
      totalPages: Math.ceil(total / limit),
      totalRecords: total,
      transactions,
    });
  } catch (error) {
    console.error("Wallet activity error:", error);
    res.status(500).json({ message: "Server error while fetching wallet activity" });
  }
};