import { Request, Response } from 'express';
import { AppDataSource } from '../config/data-source';
import { Config } from '../entities/Config';

export const setConfig = async (req: Request, res: Response) => {
  try {
    const repo = AppDataSource.getRepository(Config);
    const body = req.body;
    const configs = Array.isArray(body) ? body : [body];
    const validConfigs = configs.filter(c => c.key && c.value);
    if (validConfigs.length === 0) {
      return res.status(400).json({
        message: 'Invalid request. Expected { "key": "points_per_kg", "value": "5" } or array of such objects.',
      });
    }

    for (const item of validConfigs) {
      let existing = await repo.findOne({ where: { key: item.key } });
      if (existing) {
        existing.value = item.value;
        await repo.save(existing);
      } else {
        const newConfig = repo.create({ key: item.key, value: item.value });
        await repo.save(newConfig);
      }
    }

    res.status(200).json({ message: 'Configuration updated successfully' });
  } catch (error) {
    console.error('Error updating config:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const getConfig = async (req: Request, res: Response) => {
  try {
    const repo = AppDataSource.getRepository(Config);
    const all = await repo.find();
    res.json(all);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error fetching config' });
  }
};
