import { Request, Response } from "express";
import { AppDataSource } from "../config/data-source";
import { User } from "../entities/User";
import { RecycleRequest, RecycleStatus } from "../entities/RecycleRequests";
import { Referral } from "../entities/Referral";
import { Wallet } from "../entities/Wallet";
import multer from "multer";
import path from "path";
import fs from "fs";
import { logWalletTransaction } from "../middleware/transactionLogger";
import { TransactionType } from "../entities/WalletTransaction";

// MULTER CONFIGURATION
const uploadDir = path.join(__dirname, "../../uploads");

// Ensure the upload folder exists
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  },
});

const fileFilter = (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
  if (!allowedTypes.includes(file.mimetype)) {
    return cb(new Error("Only .jpg, .jpeg, and .png files are allowed!"));
  }
  cb(null, true);
};

export const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 1 * 1024 * 1024 }, // 1MB
});


// CREATE RECYCLE REQUEST
export const createRecycleRequest = async (req: any, res: Response) => {
  try {
    const userId = req.user.id;
    const { comment, weightKg, address } = req.body;

    // Validate file
    const pictureFile = req.file;
    if (!pictureFile) {
      return res.status(400).json({ message: "Please upload a picture" });
    }

    const pictureUrl = `/uploads/${pictureFile.filename}`; // accessible relative path

    const userRepo = AppDataSource.getRepository(User);
    const recycleRepo = AppDataSource.getRepository(RecycleRequest);
    const referralRepo = AppDataSource.getRepository(Referral);
    const walletRepo = AppDataSource.getRepository(Wallet);

    const user = await userRepo.findOne({
      where: { id: userId },
      relations: ["referralsReceived", "referralsReceived.referrer"],
    });

    if (!user) return res.status(404).json({ message: "User not found" });

    // Use provided or fallback address from profile
    const userAddress =
      address ||
      `${user.houseNumber || ""} ${user.street || ""}, ${user.area || ""}, ${user.city || ""}, ${user.state || ""}. Nearest Bus Stop: ${user.nearestBusStop || ""}`;

    const newRequest = recycleRepo.create({
      user,
      comment,
      pictureUrl,
      address: userAddress,
      weightKg,
      status: RecycleStatus.PENDING,
    });

    await recycleRepo.save(newRequest);


    // REFERRAL REWARD LOGIC
    if (user.referralsReceived && user.referralsReceived.length > 0) {
      const referral = user.referralsReceived[0];
      if (!referral.rewardGranted) {
        const referrerWallet = await walletRepo.findOne({
          where: { user: { id: referral.referrer.id } },
        });

        if (referrerWallet) {
          referrerWallet.totalPoints += 200;
          referrerWallet.availableBalanceNaira += 200;
          await walletRepo.save(referrerWallet);

          await logWalletTransaction({
            wallet: referrerWallet,
            type: TransactionType.REFERRAL,
            points: 200,
          });
        }

        referral.rewardGranted = true;
        await referralRepo.save(referral);
      }
    }

    res.status(201).json({
      message: "Recycle request submitted successfully",
      request: {
        id: newRequest.id,
        comment: newRequest.comment,
        pictureUrl: newRequest.pictureUrl,
        address: newRequest.address,
        weightKg: newRequest.weightKg,
        status: newRequest.status,
        submittedAt: newRequest.dateSubmitted,
      },
    });
  } catch (error: any) {
    console.error("Recycle request error:", error);
    res.status(500).json({
      message: error.message || "Server error while submitting recycle request",
    });
  }
};
