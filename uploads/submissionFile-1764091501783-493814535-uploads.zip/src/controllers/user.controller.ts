import { Request, Response } from "express";
import { AppDataSource } from "../config/data-source";
import { User } from "../entities/User";
import bcrypt from "bcryptjs";

// 1. Edit basic profile
export const updateProfile = async (req: any, res: Response) => {
  try {
    const userId = req.user.id;
    const { name, email, phoneNumber } = req.body;

    const userRepo = AppDataSource.getRepository(User);
    const user = await userRepo.findOne({ where: { id: userId } });

    if (!user) return res.status(404).json({ message: "User not found" });

    user.name = name ?? user.name;
    user.email = email ?? user.email;
    user.phoneNumber = phoneNumber ?? user.phoneNumber;

    const showUser = [user.name, user.email, user.phoneNumber];

    await userRepo.save(user);
    res.json({ message: "Profile updated successfully", showUser });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error updating profile" });
  }
};

// 2. Edit address
export const updateAddress = async (req: any, res: Response) => {
  try {
    const userId = req.user.id;
    const { state, city, area, street, houseNumber, nearestBusStop } = req.body;

    const userRepo = AppDataSource.getRepository(User);
    const user = await userRepo.findOne({ where: { id: userId } });

    if (!user) return res.status(404).json({ message: "User not found" });

    user.state = state ?? user.state;
    user.city = city ?? user.city;
    user.area = area ?? user.area;
    user.street = street ?? user.street;
    user.houseNumber = houseNumber ?? user.houseNumber;
    user.nearestBusStop = nearestBusStop ?? user.nearestBusStop;

    await userRepo.save(user);

    res.json({
      message: "Address updated successfully",
      address: user.fullAddress,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error updating address" });
  }
};


// 3. Update password securely
export const updatePassword = async (req: any, res: Response) => {
  try {
    const userId = req.user.id;
    const { currentPassword, newPassword, confirmPassword } = req.body;

    const userRepo = AppDataSource.getRepository(User);
    const user = await userRepo.findOne({ where: { id: userId } });

    if (!user) return res.status(404).json({ message: "User not found" });
    if (!(await user.validatePassword(currentPassword)))
      return res.status(400).json({ message: "Current password is incorrect" });
    if (newPassword !== confirmPassword)
      return res.status(400).json({ message: "New passwords do not match" });

    const salt = await bcrypt.genSalt(Number(process.env.BCRYPT_SALT) || 10);
    user.password = await bcrypt.hash(newPassword, salt);

    await userRepo.save(user);
    res.json({ message: "Password updated successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error updating password" });
  }
};
