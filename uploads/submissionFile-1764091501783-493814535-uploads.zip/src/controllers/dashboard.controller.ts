import { Request, Response } from 'express';
import { getUserDashboard } from '../services/dashboard.service';

export const getDashboard = async (req: any, res: Response) => {
  try {
    const userId = req.user.id;
    const dashboardData = await getUserDashboard(userId);
    res.json(dashboardData);
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ message: 'Failed to load dashboard' });
  }
};
