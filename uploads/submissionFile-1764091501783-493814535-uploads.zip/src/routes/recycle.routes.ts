import express from "express";
import { authenticateJWT } from "../middleware/auth.middleware";
import { createRecycleRequest, upload } from "../controllers/recycleRequest.controller";

const router = express.Router();

router.post(
  "/request",
  authenticateJWT,
  upload.single("picture"),   
  createRecycleRequest
);

export default router;
