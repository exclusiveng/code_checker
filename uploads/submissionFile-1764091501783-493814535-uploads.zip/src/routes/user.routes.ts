import { Router } from "express";
import { authenticateJWT } from "../middleware/auth.middleware";
import {
  updateProfile,
  updateAddress,
  updatePassword,
} from "../controllers/user.controller";

const router = Router();

router.put("/profile", authenticateJWT, updateProfile);
router.put("/address", authenticateJWT, updateAddress);
router.put("/password", authenticateJWT, updatePassword);

export default router;
