import { Router } from "express";
import { transferToFriend, getWalletBalance, getWalletActivity } from "../controllers/wallet.controller";
import {  } from "../controllers/wallet.controller";
import { authenticateJWT } from "../middleware/auth.middleware";

const router = Router();

router.post("/transfer", authenticateJWT, transferToFriend);
router.get("/balance", authenticateJWT, getWalletBalance);
router.get("/activity", authenticateJWT, getWalletActivity);


export default router;
