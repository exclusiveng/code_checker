import express from 'express';
import { authenticateJWT } from '../middleware/auth.middleware';
import { getDashboard } from '../controllers/dashboard.controller';
import { getConfig, setConfig } from '../controllers/config.controller';

const router = express.Router();

router.get('/', authenticateJWT, getDashboard);
router.get('/config', authenticateJWT, getConfig);
router.post('/config', authenticateJWT, setConfig);

export default router;
