import { Router } from "express";
import { authenticateJWT } from "../middleware/auth.middleware";
import { payBill } from "../controllers/bills.controller";

const router = Router();

router.post("/pay", authenticateJWT, payBill);

export default router;