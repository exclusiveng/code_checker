import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import authRoutes from "./routes/auth.routes";
import dashboardRoutes from "./routes/dashboard.routes";
import RecycleRoutes from "./routes/recycle.routes";
import walletRoutes from "./routes/wallet.routes";
import billsRoutes from "./routes/bills.routes";
import path from "path";

import userRoutes from "./routes/user.routes";

const app = express();

app.use(express.json());
app.use(cors());
app.use(helmet());
app.use(morgan("dev"));

app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100,
  })
);

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/user", userRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/recycle", RecycleRoutes);
app.use("/uploads", express.static(path.join(__dirname, "../uploads"))); // Serve uploaded images
app.use("/api/wallet", walletRoutes);
app.use("/api/bills", billsRoutes);

export default app;
