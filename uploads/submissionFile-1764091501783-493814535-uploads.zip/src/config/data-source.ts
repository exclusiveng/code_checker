import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { User } from '../entities/User';
import { WasteTransaction } from '../entities/WasteTransaction';
import { Wallet } from '../entities/Wallet';
import { Config } from '../entities/Config';
import dotenv from 'dotenv';
import { Referral } from '../entities/Referral';
import { RecycleRequest } from '../entities/RecycleRequests';
import { Transaction } from '../entities/Transaction';
import { WalletTransaction } from '../entities/WalletTransaction';

dotenv.config();

export const AppDataSource = new DataSource({
  type: 'postgres',
  url: process.env.DATABASE_URL,
  synchronize: true,
  logging: false,
  entities: [User, WasteTransaction, Wallet, Config, Referral, RecycleRequest, Transaction, WalletTransaction],
});
