import axios from "axios";

const flutterwaveApi = axios.create({
  baseURL: "https://api.flutterwave.com/v3",
  headers: {
    Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`,
  },
});

export const initiateBillPayment = async (
  type: "AIRTIME" | "DATA" | "POWER",
  customer: string,
  amount: number,
  reference: string,
  biller_code: string,
  biller_name: string
) => {
  try {
    const response = await flutterwaveApi.post("/bills", {
      country: "NG",
      customer,
      amount,
      type,
      reference,
      biller_code,
      biller_name,
    });
    return response.data;
  } catch (error: any) {
    console.error("Flutterwave API Error:", error.response?.data || error.message);
    throw new Error(error.response?.data?.message || "Failed to initiate bill payment with Flutterwave.");
  }
};