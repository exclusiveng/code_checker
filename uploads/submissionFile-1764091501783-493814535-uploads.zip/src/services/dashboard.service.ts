import { AppDataSource } from "../config/data-source";
import { WasteTransaction } from "../entities/WasteTransaction";
import { Config } from "../entities/Config";
import { User } from "../entities/User";

export const getUserDashboard = async (userId: string) => {
  const txRepo = AppDataSource.getRepository(WasteTransaction);
  const configRepo = AppDataSource.getRepository(Config);
  const userRepo = AppDataSource.getRepository(User);

  // Validate user existence
  const user = await userRepo.findOne({
    where: { id: userId },
    relations: ["wasteTransactions"],
  });
  if (!user) throw new Error("User not found");

  // Get config values (points per kg, naira per point)
  const configValues = await configRepo.find();
  const config = Object.fromEntries(configValues.map((c) => [c.key, parseFloat(c.value)]));

  const pointsPerKg = config.points_per_kg ?? 5;
  const nairaPerPoint = config.naira_per_point ?? 1;

  // User transactions
  const transactions = user.wasteTransactions ?? [];

  const totalWasteKg = transactions.reduce((sum, t) => sum + (t.weightKg ?? 0), 0);
  const totalCo2Saved = transactions.reduce((sum, t) => sum + (t.co2Saved ?? 0), 0);

  // Find uncashed transactions (pending withdrawal)
  const uncashedTx = transactions.filter((t) => !t.cashedOut);
  const uncashedPoints = uncashedTx.reduce((sum, t) => sum + (t.weightKg ?? 0) * pointsPerKg, 0);
  const uncashedValue = uncashedPoints * nairaPerPoint;

  // Compute total points and total earnings from all transactions
  const totalPoints = transactions.reduce((sum, t) => sum + (t.weightKg ?? 0) * pointsPerKg, 0);
  const totalEarningsNaira = totalPoints * nairaPerPoint;

  return {
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    },
    metrics: {
      totalWasteKg,
      totalCo2Saved,
      totalPoints,
      totalEarningsNaira,
      availableBalance: uncashedValue,
    },
    conversionRates: {
      pointsPerKg,
      nairaPerPoint,
    },
  };
};
