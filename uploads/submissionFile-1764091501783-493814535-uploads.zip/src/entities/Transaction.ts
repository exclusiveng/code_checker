import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from "typeorm";
import { User } from "./User";

export enum TransactionType {
  TRANSFER = "TRANSFER",
  REFERRAL_REWARD = "REFERRAL_REWARD",
  RECYCLE_REWARD = "RECYCLE_REWARD",
}

@Entity()
export class Transaction {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => User)
  sender!: User;

  @ManyToOne(() => User)
  recipient!: User;

  @Column("decimal", { precision: 10, scale: 2 })
  amount!: number;

  @Column({
    type: "enum",
    enum: TransactionType,
    default: TransactionType.TRANSFER,
  })
  type!: TransactionType;

  @CreateDateColumn()
  createdAt!: Date;
}
