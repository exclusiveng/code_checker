import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from "typeorm";
import { User } from "./User";

export enum RecycleStatus {
  PENDING = "pending",
  APPROVED = "approved",
  COMPLETED = "completed",
  REJECTED = "rejected",
}

@Entity()
export class RecycleRequest {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => User, user => user.recycleRequests)
  user!: User;

  @Column({ type: "text", nullable: true })
  comment!: string;

  @Column({ type: "text", nullable: true })
  pictureUrl!: string;

  @Column({ type: "decimal", precision: 10, scale: 2 })
  weightKg!: number;

  @Column({ type: "enum", enum: RecycleStatus, default: RecycleStatus.PENDING })
  status!: RecycleStatus;

  @Column({ type: "text" })
  address!: string;

  @CreateDateColumn()
  dateSubmitted!: Date;
}
