import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { User } from './User';

@Entity()
export class WasteTransaction {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @ManyToOne(() => User, user => user.wasteTransactions)
  user!: User;

  @Column({ type: 'float' })
  weightKg!: number;

  @Column({ type: 'float', default: 0 })
  co2Saved!: number;

  @Column({ default: false })
  cashedOut!: boolean;

  @CreateDateColumn()
  createdAt!: Date;
}
