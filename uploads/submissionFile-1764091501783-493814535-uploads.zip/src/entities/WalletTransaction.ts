import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  CreateDateColumn,
} from "typeorm";
import { Wallet } from "./Wallet";

export enum TransactionType {
  REFERRAL = "referral",
  RECYCLE_REWARD = "recycle_reward",
  TRANSFER_IN = "transfer_in",
  TRANSFER_OUT = "transfer_out",
  CASH_OUT = "cash_out",
  BILLS = "bills",
}

@Entity()
export class WalletTransaction {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => Wallet, (wallet) => wallet.transactions, { onDelete: "CASCADE" })
  wallet!: Wallet;

  @Column({ type: "enum", enum: TransactionType })
  type!: TransactionType;

  @Column({ type: "float" })
  points!: number;

  @Column({ type: "float" })
  nairaValue!: number;

  @Column({ nullable: true })
  description?: string;

  @CreateDateColumn()
  createdAt!: Date;
}
