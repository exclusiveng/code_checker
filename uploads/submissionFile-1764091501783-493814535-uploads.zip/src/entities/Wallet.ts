import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToOne,
  OneToMany,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";
import { User } from "./User";
import { WalletTransaction } from "./WalletTransaction";

@Entity()
export class Wallet {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @OneToOne(() => User, { eager: true, onDelete: "CASCADE" })
  @JoinColumn()
  user!: User;

  @Column({ type: "float", default: 0 })
  totalPoints!: number;

  @Column({ type: "float", default: 0 })
  totalEarningsNaira!: number;

  @Column({ type: "float", default: 0 })
  availablePoints!: number;

  @Column({ type: "float", default: 0 })
  availableBalanceNaira!: number;

  @Column({ type: "float", default: 0 })
  totalWithdrawn!: number;

  @OneToMany(() => WalletTransaction, (tx) => tx.wallet, { cascade: true })
  transactions!: WalletTransaction[];

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;
}
