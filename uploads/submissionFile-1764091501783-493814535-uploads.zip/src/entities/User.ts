import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  BeforeInsert,
  OneToMany,
} from "typeorm";
import bcrypt from "bcryptjs";
import { WasteTransaction } from "./WasteTransaction";
import { Referral } from "./Referral";
import { RecycleRequest } from "./RecycleRequests";
import { randomBytes } from "crypto";

export enum UserRole {
  HOUSEHOLD = "household",
  COLLECTOR = "collector",
}

@Entity()
export class User {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @Column({ unique: true })
  email!: string;

  @Column()
  name!: string;

  @Column()
  phoneNumber!: string;

  @Column({ nullable: true })
  nin!: string;

  // Address fields
  @Column({ nullable: true })
  state!: string;

  @Column({ nullable: true })
  city!: string;

  @Column({ nullable: true })
  area!: string;

  @Column({ nullable: true })
  street!: string;

  @Column({ nullable: true })
  houseNumber!: string;

  @Column({ nullable: true })
  nearestBusStop!: string;

  @Column()
  password!: string;

  @Column({ type: "varchar", nullable: true })
  otpCode!: string | null;

  @Column({ type: "timestamptz", nullable: true })
  otpExpiresAt!: Date | null;

  @Column({
    type: "enum",
    enum: UserRole,
    default: UserRole.HOUSEHOLD,
  })
  role!: UserRole;

  @Column({ unique: true })
  referralCode!: string;

  @BeforeInsert()
  generateReferralCode() {
    // 8-character alphanumeric code
    this.referralCode = randomBytes(4).toString("hex").toUpperCase();
  }

  @OneToMany(() => WasteTransaction, (transaction) => transaction.user)
  wasteTransactions!: WasteTransaction[];

  @OneToMany(() => Referral, (referral) => referral.referrer)
  referralsMade!: Referral[];

  @OneToMany(() => Referral, (referral) => referral.referredUser)
  referralsReceived!: Referral[];

  @OneToMany(() => RecycleRequest, (r) => r.user)
  recycleRequests!: RecycleRequest[];

  @CreateDateColumn()
  createdAt!: Date;

  @UpdateDateColumn()
  updatedAt!: Date;

  @BeforeInsert()
  async hashPassword() {
    const salt = await bcrypt.genSalt(Number(process.env.BCRYPT_SALT) || 10);
    this.password = await bcrypt.hash(this.password, salt);
  }

  async validatePassword(password: string): Promise<boolean> {
    return bcrypt.compare(password, this.password);
  }

  get fullAddress(): string {
    const parts = [
      this.houseNumber,
      this.street,
      this.area,
      this.city,
      this.state,
      this.nearestBusStop ? `near ${this.nearestBusStop}` : "",
    ].filter(Boolean);
    return parts.join(", ");
  }
}
