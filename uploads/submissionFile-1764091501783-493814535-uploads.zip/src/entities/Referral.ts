import { Entity, PrimaryGeneratedColumn, ManyToOne, Column, CreateDateColumn } from "typeorm";
import { User } from "./User";

@Entity()
export class Referral {
  @PrimaryGeneratedColumn("uuid")
  id!: string;

  @ManyToOne(() => User, (user) => user.referralsMade)
  referrer!: User;

  @ManyToOne(() => User, (user) => user.referralsReceived)
  referredUser!: User;

  @Column({ default: false })
  rewardGranted!: boolean;

  @CreateDateColumn()
  createdAt!: Date;
}
