# if 5 > 2:
#     print("5 is greater than 2")
# else:
#     print("5 is not greater than 2")

#     # this is a comment

# x= 5
# y= "Ayo"
# print(x)
# print(y)

# x="I"
# y="am"
# z="Awesome"
# print(x, y, z)

# x= "awesome"
# def myfunc():
#     print("Python is " + x)
# myfunc()

# x= "awesome"
# def myfunc():
#     x = "fantastic"
#     print("Python is " + x)
# myfunc()

# print("Python is " + x)


def myfunc():
    global x
    x = "fantastic"
myfunc()
print("Python is " + x)